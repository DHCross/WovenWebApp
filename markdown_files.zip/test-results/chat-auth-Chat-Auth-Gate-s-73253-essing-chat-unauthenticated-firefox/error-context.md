# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - heading "Poetic Brain Unavailable" [level=1] [ref=e3]
    - paragraph [ref=e4]: Raven's chat interface is temporarily offline while we work through the Auth0/Perplexity integration. Math Brain reports and the rest of the site remain fully available. Check back soon for the full FIELD → MAP → VOICE handoff.
    - link "Return to Home" [ref=e5] [cursor=pointer]:
      - /url: /
  - alert [ref=e6]
```
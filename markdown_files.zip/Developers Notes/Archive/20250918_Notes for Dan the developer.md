npx next dev -p 4000
is what to use to launch the server in development mode.
# Notes for Dan the developer

Main Branch Locked:

This is likely a GitHub branch protection rule. You can work on a feature branch and submit a pull request for review.
If you need to push directly to main, you’ll need repo admin permissions or to request a review/merge.